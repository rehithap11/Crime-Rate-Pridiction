from django.shortcuts import render
import numpy as np
#import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
# Create your views here.
def cdf(request):
	if request.method == "POST":
		t = int(request.POST['report_year'])
		a = int(request.POST['population'])
		b = int(request.POST['robberies'])
		dataset = pd.read_csv('sample/crime.csv')
		x=dataset.iloc[:,:-1].values
		y=dataset.iloc[:,3:].values
		x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2,random_state=0)
		model = RandomForestRegressor(n_estimators=10,random_state = 0)
		model.fit(x_train,y_train)
		y_predict = model.predict([[t,a,b]])

		return render(request,'scy/cform.html',{'f':y_predict[0]})
	return render(request,'scy/cform.html')

def  abt(request):
	return render(request,'scy/about.html')

def home(request):
	return render(request,'scy/home.html')